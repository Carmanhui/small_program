webd 网盘

下载地址
http://mydisk.ml:5156/webd-win32.7z (Windows 平台)
http://mydisk.ml:5156 (同时为只读演示地址)
http://webdisk.ys168.com (备用)

预览图
https://imgurl.org/temp/1810/479a95ce0a8d6fb7.png
https://imgurl.org/temp/1810/f5ef062247dd9d3c.png

介绍:
  这是一个极轻量级的用于自己搭建简易网盘的软件
  解压后不同平台的程序文件只有 60 KB 至 90 KB, 包含前后端和服务器
  可以完成文件上传下载, 手机在线看电影的功能, 亦可拍摄视频照片后自动上传分享与其它用户.
  支持 Windows、Linux、甚至 OpenWrt 路由器平台
  还有高性能高并发的特性(采用 IOCP 和 epoll)，可承担大量用户同时使用

使用说明

Windows 平台安装方法, 需 Win7 或更高版本, 本软件为绿色版，解压后即可使用。
  1. 下载文件名包含 win32 的压缩包(64位Windows亦可用), 例如 http://mydisk.ml:5156/webd-win32.tar.gz

  2. 用 7zip、winrar 等工具把下载的文件解压到适当的目录

  3. 进入解压到的目录:
    1) webd.exe 为主程序, 可直接双击运行，运行后在状态栏有图标。
    2) tools.cmd 运行后有个简易的菜单界面, 用于控制开机启动和桌面快捷方式, 右键管理员运行时可以控制防火墙.

使用方法:
  1. 启动后双击状态栏图标, 默认浏览器会打开本软件的界面, 支持 Chrome FireFox 和大部分手机上的浏览器, IE 可能会空白.

  2. 用手机打开浏览器地址栏的地址, 可以在手机上使用

  3. web 界面上的 New 用于新建文件夹

  4. 按 Upload 会弹出选择文件对话框
     可选中多个文件上传, 上传过程中有进度显示, 可以上传很大的文件.
	 部分手机可以长按文件名进入多选模式, 但有的手机系统不支持
	 手机上还可以选择拍照或录像后自动上传, 之后其它设备可以在线观看.

  5. 删除文件, 单击列表中文件名之外的位置进行选中, 选中的文件名有下划线, 选中一个或多个后可以删除
     (文件不会真正从系统删除，而是位于 web 目录下的 .Trash 文件夹内)

  6. 浏览器支持的视频比如 mp4、flv 等, 可以直接在手机或桌面浏览器观看

  7. 浏览器不支持的视频, 可以在手机上安装 mxplayer 播放器, 系统会自动调用之.

高级使用方法:
  1. 虚拟目录
     软件本身不支持虚拟目录, 但可以用操作系统的目录链接功能变相实现.
	 比如软件位于 C:\webd , web 目录默认就是 C:\webd\web , 那么如果要通过 web 界面访问 F:\dir2 可如下操作:
	   右键编辑 MakeLink.cmd 进行编辑脚本
	   在文件中的 pause 前面一行添加以下内容并保存关闭.
	   mklink /D C:\webd\web\dir2 F:\dir2
	   然后右键管理员运行这个文件, 即可创建目录链接

  2. 隐藏文件列表, 当一个目录下的文件需要隐藏的时候, 可以在这个目录下新建一个0字节的 index.html 文件即可.
     之后可以通过类似 http://xxx:port/#/HideDir/ 方式进行访问

  3. 在文件列表中隐藏某个文件或文件夹，只要命令行下把某个文件重名名成点 . 开头的即可隐藏
     比如 cmd 命令窗口下运行:
	   cd /d f:\dir2
	   move xxxx .xxxx

  4. 更改默认的 9212 端口, 在 webd 快捷方式那里, 右键属性,
     在目标那栏添最后 加个空格 然后加 -l 9900 即可更改端口, 注意原来的内容不要去掉
	 (注意有桌面和 开始 -> 所有程序 -> 启动 两个地方的快捷方式)

  5. 更改默认的 web 目录, 同 4 中的方法, 添加 -w E:\ 即可使用整个 E 盘作为 web目录

  6. 隐藏状态栏图标, 同 4 中的方法, 添加 -h
	 

Linux 和 OpenWrt 的安装方法:

  文件名包含 linux-x86_64 的压缩包适用于平常的 Linux 发行版, 需要内核 3.15 以及以上, glibc 2.17 以及以上.
  文件名包含其它内容的为 OpenWrt 版本, 其中带 cc 的适用于 Openwrt Chaos Calmer 15.05.1 , 不带 cc 的适用于最新版.
  
  目前支持的几个大种类有:
    ar71xx ramips/mt7620 ramips/mt7621 bcm53xx ipq806x x86_64

    每个大种类支持很多不同的硬件.
    可以在这里 https://downloads.lede-project.org/snapshots/targets/ 去查询对应的硬件列表
    即使不在列表中, 如果CPU一样且所用固件是从 OpenWrt 修改而来的, 也一样能支持.
    作者没有那么多的硬件来组合各处不同的固件一一测试, 请自行尝试运行, 然后反馈到论坛或发邮件 zhngq2312@gmail.com

  安装过程:
    以普通 linux 发行版为例,
	通过 ssh、串口、或者本地控制台进入命令界面
	cd /tmp
	wget http://mydisk.ml:5156/.lastest/webd-linux-x86_64.tar.gz
	tar -xzvf webd-linux-x86_64.tar.gz
	/tmp/webd/webd -w /tmp/webd/web # 这里会停住并显示一些日志

	用浏览器打开路由器或 linux 机器对应的IP加端口, 比如 http://192.168.11.1:9212 就能看到web界面了.

	如果要后台运行并且每次开机都能自动启动, 回到刚才的命令界面按 Ctrl+C 关闭刚才的进程
	mkdir -pv /srv/webd
	mv -fv /tmp/webd/webd /usr/bin
	mv -fv /tmp/webd/web /srv/webd
	# rm -r /tmp/webd /tmp/webd-linux-x86_64.tar.gz # 可选, 删除不用的文件
	
	然后编辑 /etc/rc.local 添加以下内容, 并运行一次以下内容以便立即生效
	/usr/bin/webd -l 9212 -w /srv/webd/web &>/dev/null &
	端口和路径都可以直接更改的.
	(当然也可以写 init 启动脚本或 systemd 启动文件)

	如果要访问的文件不在 /srv/webd/web 下面怎么办呢, 可以创建符号连接, 比如:
	  ln -sv /mnt/sda1 /srv/webd/web

by zhngq2312@gmail.com
