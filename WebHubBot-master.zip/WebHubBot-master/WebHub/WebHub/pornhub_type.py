#coding:utf-8
"""归纳PornHub资源链接"""
PH_TYPES = [
    '',
    'recommended',
    'video?o=ht', # hot
    'video?o=mv', # Most Viewed
    'video?o=tr', # Top Rate

    # Examples of certain categories
    # 'video?c=1',  # Category = Asian
    # 'video?c=111',  # Category = Japanese
]
